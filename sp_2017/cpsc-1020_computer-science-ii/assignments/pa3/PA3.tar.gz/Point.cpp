#include "Point.h"

void Point::setX(double x)
{
  this->xValue = x;
}

void Point::setY(double y)
{
  this->yValue = y;
}

double Point::getX()
{
  return xValue;
}

double Point::getY()
{
  return yValue;
}
