* Using Enums to record states of sender and receivers, I recorded and changed states inside methods
* Used a dedicated but slim method to calculate Checksums
* Used a packet buffer in case of needing to resend a single packet -- can using keep one saved, which is in line with RDT 3.0
