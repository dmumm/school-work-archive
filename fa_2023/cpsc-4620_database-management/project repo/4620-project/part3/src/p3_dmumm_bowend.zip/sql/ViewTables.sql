-- Bowen Main

USE Pizzeria
;
SELECT * FROM full_order_discount;
SELECT * FROM pizza_order_discount;
SELECT * FROM pizza_order_topping;
SELECT * FROM pizza_order;
SELECT * FROM base_pizza;
SELECT * FROM topping;
SELECT * FROM discount;
SELECT * FROM coupon;
SELECT * FROM dinein;
SELECT * FROM pickup;
SELECT * FROM delivery;
SELECT * FROM address;
SELECT * FROM customer;
SELECT * FROM full_order;