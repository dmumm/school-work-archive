#include "free_list.h"

// Adds a new block of memory to the free list of the given page
void add_to_free_list(page_t *page, void *ptr) {
    free_list_node_t *new_node = (free_list_node_t *)ptr;
    new_node->next = page->free_list;  // Assuming page has a free_list pointer
    page->free_list = new_node;
}

// Finds a free block in the page's free list
free_list_node_t *find_fit(page_t *page){
    return page->free_list; // Returns the first node if available, otherwise NULL
}

// Removes a node from the free list of the given page
void remove_from_free_list(page_t *page, free_list_node_t *node) {
    if (node == NULL || page == NULL || page->free_list == NULL) {
        return;
    }

    if (page->free_list == node) {
        page->free_list = node->next;
        return;
    }

    free_list_node_t *current = page->free_list;
    while (current->next != NULL && current->next != node) {
        current = current->next;
    }

    if (current->next != NULL) {
        current->next = node->next;
    }
}
