#ifndef PAGE_H
#define PAGE_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <sys/mman.h>   // For mmap and munmap
#include <stdlib.h>     // For exit and EXIT_FAILURE
#include <stdio.h>      // For perror

#define PAGE_SIZE 4096  // Size of a memory page (4 KB)

// Forward declaration of free_list_node_t
typedef struct free_list_node free_list_node_t;

typedef struct page {
    size_t object_size;          // Size of objects this page handles
    free_list_node_t *free_list; // Free list for this page
} page_t;

// Include free_list.h after the definition of page_t
#include "free_list.h"

// Function declarations for page management
page_t *request_page();
void release_page(page_t *page);

#endif // PAGE_H
