#include "page.h"

// Requests a new page from the operating system
page_t *request_page(size_t object_size) {
    void *page_memory = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE,
                             MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (page_memory == MAP_FAILED) {
        perror("Page allocation failed");
        exit(EXIT_FAILURE);
    }

    page_t *page = (page_t *)page_memory;
    page->object_size = object_size;
    page->free_list = NULL;

    return page;
}


// Releases a page back to the operating system
void release_page(page_t *page) {
    if (page != NULL) {
        munmap(page, PAGE_SIZE);
    }
}