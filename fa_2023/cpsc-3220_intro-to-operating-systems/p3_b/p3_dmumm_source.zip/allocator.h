/***********************************************************************************

   Author: Dylan Mumm
   Student ID: C18070517

   Professor Name: Jacob Sorber
   Semester: Fall 2023
   Class ID: CPSC 3220
   Class Title: Operating Systems
   Section ID: 001

   Project Name:  Project #3: MemoryAllocator

***********************************************************************************/

#ifndef ALLOCATOR_H
#define ALLOCATOR_H

#include <sys/mman.h>
#include <stdio.h>  // For perror
#include <stdlib.h> // For exit
#include <stddef.h>
#include <assert.h>

#include "page.h"
#include "page_list.h"
#include "free_list.h"


#define INITIAL_MEM_REQUEST 4096  // Size of a memory page (4 KB)
#define MAX_SMALL_SIZE 1024  // Maximum size for small objects

typedef struct size_to_page_map {
    size_t object_size;
    page_list_node_t *pages_head; // Head of the free list of pages for this object size
} size_to_page_map_t;


// Allocator calls
void *my_malloc(size_t size);
void *my_calloc(size_t num, size_t size);
void *my_realloc(void *ptr, size_t size);
void  my_free(void *ptr);

// Initialization and cleanup functions
void initialize_allocator();
void finalize_allocator();

// Additional helper functions as needed
page_t *get_page_for_size(size_t size); // Gets (or creates) a page suitable for the given size
int get_size_class_index(size_t size);


#endif // ALLOCATOR_H