#ifndef FREE_LIST_H
#define FREE_LIST_H

#include <stdlib.h>  // Standard library for basic functions
#include <sys/mman.h>  // For memory mapping (mmap, munmap)
#include <fcntl.h>  // For file control options
#include <string.h>  // For string manipulation functions

// Forward declaration of page_t
typedef struct page page_t;

typedef struct free_list_node {
    struct free_list_node *next;  // Pointer to the next node in the list
} free_list_node_t;

// Include page.h after the definition of free_list_node_t
#include "page.h"

// Function declarations for free list operations
void add_to_free_list(page_t *page, void *ptr);
void remove_from_free_list(page_t *page, free_list_node_t *node);
free_list_node_t *find_fit(page_t *page);

#endif // FREE_LIST_H
