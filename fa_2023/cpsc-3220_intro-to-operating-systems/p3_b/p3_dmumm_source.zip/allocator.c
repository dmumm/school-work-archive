/***********************************************************************************

   Author: Dylan Mumm
   Student ID: C18070517

   Professor Name: Jacob Sorber
   Semester: Fall 2023
   Class ID: CPSC 3220
   Class Title: Operating Systems
   Section ID: 001

   Project Name:  Project #3: MemoryAllocator

***********************************************************************************/

//#include "common_libs.h"
#include "allocator.h"

#include <assert.h>

// Static variable for the base of memory pool
static void *base_memory = NULL;

static int num_size_classes = 10; // TODO: placeholder, replace with actual number of size classes

void initialize_allocator() {
    // Initialize your allocator's data structures here
}

void finalize_allocator() {
    // Clean up and release resources used by the allocator here
}

void *my_malloc(size_t size) {
    // Handle zero-size allocations
    if (size == 0) {
        return NULL;
    }

    // Find or allocate a page suitable for the size
    page_t *page = get_page_for_size(size);
    if (page == NULL) {
        return NULL; // If no page is available or can be allocated
    }

    // Find a fit for the allocation in the page's free list
    free_list_node_t *node = find_fit(page);
    if (node == NULL) {
        return NULL; // No free block available of the required size
    }

    // Remove the node from the free list
    remove_from_free_list(page, node);

    // Return the allocated block
    return (void *)node;
}

void *my_calloc(size_t num, size_t size) {
    size_t total_size = num * size;
    void *ptr = my_malloc(total_size);
    if (ptr) {
        memset(ptr, 0, total_size);
    }
    return ptr;
}

void *my_realloc(void *ptr, size_t size) {
    if (ptr == NULL) {
        return my_malloc(size);
    }
    if (size == 0) {
        my_free(ptr);
        return NULL;
    }

    // Implement reallocation logic here
    // This will involve finding the size of the current allocation,
    // allocating new space, copying data, and freeing the old block

    return NULL; // Placeholder
}

void my_free(void *ptr) {
    if (ptr == NULL) {
        return;
    }

    // Implement deallocation logic here
    // This will involve determining which page the pointer belongs to
    // and adding it back to the appropriate free list
}
void add_page_to_size_class(size_t size, page_t *page) {
    int index = get_size_class_index(size);  // Implement this based on your size class calculation
    if (index < 0 || index >= num_size_classes) {
        // Handle error: size class index out of range
        return;
    }

    page_list_node_t *new_node = (page_list_node_t *)my_malloc(sizeof(page_list_node_t));
    if (new_node == NULL) {
        // Handle error: failed to allocate node
        return;
    }

    new_node->page = page;
    new_node->next = get_page_for_size(size);
}

int get_size_class_index(size_t size) {
    // Implement logic to determine the size class index based on the object size
    // Example: return size / SOME_SIZE_MULTIPLIER - 1;
    return -1;  // Placeholder
}

// TODO: need to retrieve dynamiic number of size classes
page_t *get_page_for_size(size_t size) {
    int index = get_size_class_index(size);  // Implement this based on your size class calculation
    if (index < 0 || index >= num_size_classes) {
        // Handle error: size class index out of range
        return NULL;
    }

    page_list_node_t *current = get_page_list_for_size(size);
    while (current != NULL) {
        if (/*TODO: check if current->page can serve the request */ 1) {
            return current->page;
        }
        current = current->next;
    }

    // No suitable page found, request a new one
    page_t *new_page = request_page(size);  // TODO: Implement this function
    add_page_to_size_class(size, new_page);
    return new_page;
}