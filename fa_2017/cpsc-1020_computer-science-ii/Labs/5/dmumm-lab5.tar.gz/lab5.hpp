// Dylan Mumm, dmumm
// Lab 5, Section 002
// Nick Glyder, nglyder

#ifndef LAB5_H
#define LAB5_H

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

void bubble_sort(int[], int);

#endif
