//@ Dylan Mumm, 2120
//@ Assignment 1
//@ February 11th

#ifndef CORPUS_H
#define CORPUS_H
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

using namespace std;

class Corpus {

  public:

    // constructors
    Corpus();
    Corpus(string);

    // function
    double proportion(char);

  private:

    // Member variable
    double prop[26];

};
#endif
